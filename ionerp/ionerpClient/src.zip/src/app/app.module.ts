import { ToastService } from './common/toast.service';
import { PostService } from './services/post.service';
import {HttpModule} from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { DataTablesModule } from 'angular-datatables';
import { NgModule, Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { TitleCasePipe } from './title-case.pipe';
import { MainHeaderComponent } from './main-header/main-header.component';
import { MainSidenavComponent } from './main-sidenav/main-sidenav.component';
import { FooterComponent } from './footer/footer.component';
import { ContentWrapperComponent } from './content-wrapper/content-wrapper.component';
import { UserFormComponent } from './user-form/user-form.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterializeModule } from 'ng2-materialize';
import { RouterModule } from '@angular/router';
import { DepartmentComponent } from './department/department.component';
import {ToasterModule, ToasterService} from 'angular2-toaster';
import { ToastComponent } from './toast/toast.component';
@NgModule({
  declarations: [
    AppComponent,
    TitleCasePipe,
    MainHeaderComponent,
    MainSidenavComponent,
    FooterComponent,
    ContentWrapperComponent,
    UserFormComponent,
    UserRegistrationComponent,
    DepartmentComponent
    
  ],
  imports: [
    BrowserModule,
    ToasterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    BrowserAnimationsModule,
    DataTablesModule,
    MaterializeModule.forRoot(),
    RouterModule.forRoot([
      {
      path:'', 
      component:DepartmentComponent
    },
  ]),

  ],
  providers: [
    PostService,
    ToastService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
