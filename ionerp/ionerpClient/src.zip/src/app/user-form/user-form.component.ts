import { AppValidators } from './../common/app.validator';
import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl, Validators} from '@angular/forms';
import { Http, Headers,Response } from "@angular/http";


@Component({
  selector: 'user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent  {
form = new FormGroup({
  firstname: new FormControl('',[
    Validators.required,
    Validators.pattern('^[a-zA-Z]+$'),
    Validators.minLength(3),
    Validators.maxLength(50),
    AppValidators.shouldBeUnique
  ]),
  lastname: new FormControl('',[
    Validators.required,
    Validators.pattern('^[a-zA-Z]+$'),
    Validators.minLength(1),
    Validators.maxLength(50), //^[0-9]*$
  ]),
  contactnumber :  new FormControl('',[
    Validators.required,
    Validators.pattern('^[0-9]*$'),
    Validators.minLength(7),
    Validators.maxLength(10), //
  ]),
  address: new FormControl('',[
    Validators.required,
    Validators.minLength(5),
    Validators.maxLength(100), //
  ]),
});
get firstname(){
  return this.form.get('firstname');
}
get lastname(){
  return this.form.get('lastname');
}
get contact(){
  return this.form.get('contactnumber');
}
get address(){
  return this.form.get('address');
}
 private url="http://127.0.0.1/IonERP/Users/index";
  constructor(private http:Http){
    
  }
  createPost(inputFirstName:HTMLInputElement){
    console.log(inputFirstName.value);
    let fname = inputFirstName.value;
    let postData = {
      inputValue:inputFirstName.value
    };
    let bodyData = new URLSearchParams(fname)
    bodyData.set('firstname',fname);
    console.log(postData);
    let headers = new Headers();
    headers.append('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
    this.http.post(this.url,JSON.stringify(postData),{
      headers:headers
    }).subscribe(Response=>{
      console.log(Response.json());
    });
  }
}
