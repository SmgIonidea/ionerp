import { AbstractControl, ValidationErrors } from '@angular/forms';
export class CharctersOnlyValidation{
   static   CharctersOnly(control:AbstractControl):ValidationErrors|null{
       if(control.value){
        if((control.value as string).match('[a-zA-Z][a-zA-Z ]+[a-zA-Z]$')){
            return null;
            
        }else{
            return {CharctersOnly:true};
        }
       }else{
           return null;
       }
            
           
        }
        
}