export class ActivitySector{

}

export class Province{
    
}

export class User{
     // initial values
  User = {
    activitySector: null,
    address: '',
    address2: '',
    city: '',
    firstName: '',
    gender: 'man',
    jobTitle: '',
    jobDescription: '',
    jobPrivate: true,
    jobType: 'permanent',
    lastName: '',
    phoneNumbers: [],
    postalCode: '',
    province: null,
  };
}